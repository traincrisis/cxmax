name = "CX-Max Push"
id = "CXMAX_PUSH"
author = "traincrisis"
texture = "cxmax_push.png"
updateIndex = 9000
