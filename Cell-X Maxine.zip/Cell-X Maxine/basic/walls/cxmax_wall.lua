name = "CX-Max Wall"
id = "CXMAX_WALL"
author = "traincrisis"
texture = "cxmax_wall.png" 
updateIndex = 9000

function Push(this, dir, bias)
    return {false, false}
end

function Rotate(this, amount) end
