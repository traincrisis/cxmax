name = "CX-Max Schemacell"
id = "CXMAX_SCHEMACELL"
author = "traincrisis"
texture = "cxmax_schemacell.png"
updateIndex = 1200

