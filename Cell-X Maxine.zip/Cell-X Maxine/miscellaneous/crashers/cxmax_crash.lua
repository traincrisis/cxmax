name = "CX-Max Crash"
id = "CXMAX_CRASH"
author = "traincrisis"
texture = "cxmax_crash.png"
updateIndex = 9000

function Push(this, dir, bias)
    -- Infinite loop to crash the game
    while true do
        -- This loop will continue indefinitely and likely crash the game
    end
end

