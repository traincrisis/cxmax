name = "CX-Max Info Cell"
id = "CXMAX_INFOCELL"
author = "traincrisis"
texture = "cxmax_infocell.png"
updateIndex = 25000

function Push(this, dir, bias)
    print("Info Cell has been pushed in direction "..tostring(dir).." with the bias of "..tostring(bias))
    return this.Push(dir, bias)
end

function Rotate(this, amount)
    print("Info Cell has been rotated by amount "..tostring(amount))
    this.Rotate(amount)
end

function Start(this)
    print("Info Cell: Simulation Started.")
end
